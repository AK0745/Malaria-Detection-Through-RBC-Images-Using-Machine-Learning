Created a machine learning model for malaria detection through RBC Images. It uses various models, algorithms and edge detection techniques to get the best accuracy.

Dataset is taken from NIH.
Kaggle Link for dataset: https://www.kaggle.com/datasets/iarunava/cell-images-for-detecting-malaria

This Project belongs to and is a work of following IIITD Students: 
Vivek Jain (2021218)
Manan Garg (2021163)
Tushar (2020478)
